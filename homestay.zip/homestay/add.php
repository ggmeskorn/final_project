<?php

$db = mysqli_connect("localhost", "root", "", "final_project");
if (!$db) {
    echo "Database connect error" . mysqli_error($db);
}
$admin_id =  $_POST['admin_id'];
$title =   $_POST['title'];
$body =  $_POST['body'];
$update_at =  $_POST['update_at'];
// $Views = $_POST['Views']
$category_news =   $_POST['category_news'];
$create_date =  date('d/m/Y h:i');
$pathImagenews = $_FILES['pathImagenews']['name'];
$imagePath = "News/" . $pathImagenews;

$tmp_name =  $_FILES['pathImagenews']['tmp_name'];
move_uploaded_file($tmp_name, $imagePath);

$db->query("INSERT INTO  news(admin_id,title,body,category_news,update_at,created_at,pathImagenews,Views)VALUES('" . $admin_id . "','" . $title . "','" . $body . "','" . $category_news . "','".$update_at."','" . $create_date . "','" . $pathImagenews . "',0)");
