<?php
header("content-type:text/javascript;charset=utf-8");
error_reporting(0);
error_reporting(E_ERROR | E_PARSE);
$link = mysqli_connect('localhost', 'root', '', "final_project");

if (!$link) {
    echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    
    exit;
}

if (!$link->set_charset("utf8")) {
    printf("Error loading character set utf8: %s\n", $link->error);
    exit();
    }

if (isset($_GET)) {
    if ($_GET['isAdd'] == 'true') {
        $email = $_GET['email'];
        $username = $_GET['username'];
        $password = $_GET['password'];
        $gender = $_GET['gender'];
        $pathImage = $_GET['pathImage'];
        $status = $_GET['status'];
        $phone = $_GET['phone'];
        $status_online = $_GET['status_online'];
        $ran_id = rand(time(), 100000000);
        
        
        $sql = "INSERT INTO `user_admin`(`id`,`unique_id`, `email`, `username`,`password`,`gender`,`phone`,`pathImage`,`status`,`status_online`) VALUES (Null,'$ran_id','$email','$username','$password','$gender','$phone','$pathImage','$status','$status_online')";

        $result = mysqli_query($link, $sql);

        if ($result) {
            echo "true";
        } else {
            echo "false";
        }

    } else echo "Welcome GameVan";
   
}
    mysqli_close($link);
