<?php 
    $db = mysqli_connect("localhost","root","","final_project");
    if(!$db){
         echo "Database connect error".mysqli_error($db);
  }
  $id = $_POST['id'];
  $db->query("DELETE FROM category_pets WHERE id = '".$id."'");
?>