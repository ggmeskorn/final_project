<?php
$db = mysqli_connect("localhost", "root", "", "final_project");
if (!$db) {
    echo "Database connect error" . mysqli_error($db);
}
$user_email = $_POST['user_email'];
$list = array();
$result = $db->query("SELECT * FROM comment WHERE isSeen = 0 AND user_email = 'ooooo'");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $list[] = $row;
    }
    echo json_encode($list);
}
