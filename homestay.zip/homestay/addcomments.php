<?php
$db = mysqli_connect("localhost","root","","final_project");
    if(!$db){
            echo "Database connect error".mysqli_error($db);
    }
    $comments = $_POST['comments'];
    $user_email = $_POST['user_email'];
    $author_post = $_POST['author_post'];

    $curDate = date('h:i');
    $post_id = $_POST['post_id'];


    // $sql = "INSERT INTO `register`(`id`, `email`, `username`,`password`,`gender`,`pathImage`,`status`) VALUES (Null, '$email','$username','$password','$gender','$pathImage','$status')";

    $db->query("INSERT INTO comment(comments,author_post,user_email,post_id,comments_date,isSeen)VALUES('".$comments."','".$author_post."','".$user_email."','".$post_id."','".$curDate."',0)");

    ?>