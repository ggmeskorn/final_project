<?php 
    $db = mysqli_connect("localhost","root","","final_project");
    if(!$db){
         echo "Database connect error".mysqli_error($db);
  }
  $id = $_POST['id'];
$result = $db->query("SELECT * FROM post_table WHERE id = '".$id."'");
$data = mysqli_fetch_array($result);
if($data['image_post'] ){
    unlink('Post/'.$data['image_post']);
}
  $db->query("DELETE FROM post_table WHERE id = '".$id."'");
?>