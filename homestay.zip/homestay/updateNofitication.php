<?php

$db = mysqli_connect("localhost", "root", "", "final_project");
if (!$db) {
    echo "Database connect error" . mysqli_error($db);
}

$id = $_POST['id'];
$db->query("UPDATE comment SET isSeen = 1 WHERE id = '".$id."'");