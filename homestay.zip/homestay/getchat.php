<?php
$db = mysqli_connect("localhost", "root", "", "final_project");
if (!$db) {
    echo "Database connect error" . mysqli_error($db);
}

$list = array();
$pid = $_POST['pid'];

$result = $db->query("SELECT * FROM messages LEFT JOIN user_admin ON user_admin.unique_id = messages.outgoing_msg_id WHERE pid = '" . $pid . "' ORDER BY msg_id DESC ");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $list[] = $row;
    }
    echo json_encode($list);
}
