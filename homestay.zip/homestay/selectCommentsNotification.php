<?php
$db = mysqli_connect("localhost", "root", "", "final_project");
if (!$db) {
    echo "Database connect error" . mysqli_error($db);
}
		$author_post = $_GET['author_post'];

$result = $db->query("SELECT id FROM comment WHERE isSeen = 0 AND author_post = '$author_post'");
$totalValue = mysqli_num_rows($result);
echo json_encode($totalValue);



// header("content-type:text/javascript;charset=utf-8");
// error_reporting(0);
// error_reporting(E_ERROR | E_PARSE);
// $link = mysqli_connect('localhost', 'root', '', "final_project");

// if (!$link) {
//     echo "Error: Unable to connect to MySQL." . PHP_EOL;
//     echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
//     echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    
//     exit;
// }

// if (!$link->set_charset("utf8")) {
//     printf("Error loading character set utf8: %s\n", $link->error);
//     exit();
// 	}

// if (isset($_GET)) {
// 	if ($_GET['isAdd'] == 'true') {
				
// 		$author_post = $_GET['author_post'];

// 		// $result = mysqli_query($link, "SELECT * FROM Petss WHERE User_Admin_id = '$User_Admin_id'");
// 		$result = mysqli_query($link,"SELECT id FROM comment WHERE isSeen = 0 AND author_post = '$author_post'");

// 		if ($result) {

// 			while($row=mysqli_fetch_assoc($result)){
// 			$output[]=$row;

// 			}	// while

// 			echo json_encode($output);

// 		} //if

// 	} else echo "Welcome Master UNG";	// if2
   
// }	// if1


// 	mysqli_close($link);
// 
