<?php

$db = mysqli_connect("localhost", "root", "", "final_project");
if (!$db) {
    echo "Database connect error" . mysqli_error($db);
}
$id = $_POST['id'];
$post_date =  $_POST['post_date'];
$comments_post =   $_POST['comments_post'];
$total_Like =   $_POST['total_Like'];
$title_post =   $_POST['title_post'];
$category_name =   $_POST['category_name'];
$create_date =  date('d/m/Y h:i');
$author_post =   $_POST['author_post'];
$body_post =  $_POST['body_post'];
$image_post = $_FILES['image_post']['name'];
$imagePath = "Post/" . $image_post;

$tmp_name =  $_FILES['image_post']['tmp_name'];
move_uploaded_file($tmp_name, $imagePath);

$db->query("UPDATE post_table SET image_post = '" . $image_post . "', author_post = '".$author_post."',post_date = '".$create_date."', title_post = '".$title_post."',body_post = '".$body_post."',category_name = '".$category_name."'WHERE id = '".$id."' ");
