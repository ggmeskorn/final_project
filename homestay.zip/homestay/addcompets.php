<?php
$db = mysqli_connect("localhost","root","","final_project");
    if(!$db){
            echo "Database connect error".mysqli_error($db);
    }
    $comments = $_POST['comments'];
    $user_email = $_POST['user_email'];
    $author_post = $_POST['author_pets'];

    $curDate = date('h:i');
    $post_id = $_POST['pets_id'];


    // $sql = "INSERT INTO `register`(`id`, `email`, `username`,`password`,`gender`,`pathImage`,`status`) VALUES (Null, '$email','$username','$password','$gender','$pathImage','$status')";

    $db->query("INSERT INTO commentspets(comments,author_pets,user_email,pets_id,comments_date,isSeen)VALUES('".$comments."','".$author_post."','".$user_email."','".$post_id."','".$curDate."',0)");

    ?>