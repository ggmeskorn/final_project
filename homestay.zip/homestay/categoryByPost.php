<?php
    $db = mysqli_connect("localhost","root","","final_project");
    if(!$db){
            echo "Database connect error".mysqli_error($db);
    }

    $name_category = $_POST['name_category'];
    $list = array();
 $result = $db->query("SELECT p.id ,p.title_post ,p.body_post ,p.category_name,p.comments_post, p.total_Like ,p.post_date, p.create_date, p.author_post,p.image_post,u.pathImage FROM post_table as p LEFT JOIN user_admin as u on p.author_post = u.username WHERE category_name = '".$name_category."'
 ");
 if($result){
    while($row = $result->fetch_assoc()){
        $list[] = $row;
    }
    echo json_encode($list);

 }
?>