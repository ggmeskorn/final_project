<?php
// $db = mysqli_connect("localhost", "root", "", "final_project");
// if (!$db) {
// 	echo "Database connect error" . mysqli_error($db);
// }

// $Id_Pets = $_POST['Id_Pets'];
// 		$username = $_POST['username'];
// $list = array();
// $result = $db->query("SELECT * FROM Image_Image WHERE Id_Pets = '".$Id_Pets."' AND username = '".$username."'");
// if ($result) {
// 	while ($row = $result->fetch_assoc()) {
// 		$list[] = $row;
// 	}
// 	echo json_encode($list);
// }
header("content-type:text/javascript;charset=utf-8");
error_reporting(0);
error_reporting(E_ERROR | E_PARSE);
$link = mysqli_connect('localhost', 'root', '', "final_project");

if (!$link) {
	echo "Error: Unable to connect to MySQL." . PHP_EOL;
	echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
	echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;

	exit;
}

if (!$link->set_charset("utf8")) {
	printf("Error loading character set utf8: %s\n", $link->error);
	exit();
}

if (isset($_GET)) {
	if ($_GET['isAdd'] == 'true') {

		// $Id_Pets = $_GET['Id_Pets'];
		$username = $_GET['username'];

		$result = mysqli_query($link, "SELECT * FROM Image_Image WHERE username = '$username'");

		if ($result) {

			while ($row = mysqli_fetch_assoc($result)) {
				$output[] = $row;
			}	// while

			echo json_encode($output);
		} //if

	} else echo "Welcome Master UNG";	// if2

}	// if1


mysqli_close($link);


//created_at updated_at deleted_at