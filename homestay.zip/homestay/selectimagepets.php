<?php
    $db = mysqli_connect("localhost","root","","final_project");
    if(!$db){
            echo "Database connect error".mysqli_error($db);
    }

    $id_pets = $_POST['id_pets'];

$list = array();
 $result = $db->query("SELECT * FROM image_pets WHERE id_pets = '".$id_pets."'");
 if($result){
    while($row = $result->fetch_assoc()){
        $list[] = $row;
    }
    echo json_encode($list);

 }
