<?php
$db = mysqli_connect("localhost", "root", "", "final_project");
// if (!$db) {
//     echo "Database connect error" . mysqli_error($db);
// }
if (!$db) {
    printf("Database connect error", mysqli_connect_error());
}
// $image_post = $_POST['image_post'];
$id_user = $_POST['id_user'];
$namepets = $_POST['namepets'];
$detailspets = $_POST['detailspets'];
$genderpets = $_POST['genderpets'];
$sterillzationpets = $_POST['sterillzationpets'];
$category_pets = $_POST['category_pets'];
$vaccinepets = $_POST['vaccinepets'];
$bodysize = $_POST['bodysize'];
$typebreed = $_POST['typebreed'];
$lat = $_POST['lat'];
$lone = $_POST['lone'];
$create_at = date('d/m/Y ');
$update_at = $_POST['update_at'];
// $pathimage = $_POST['pathimage'];
$id_pets = $_POST['id'];
// $pathimage = $_FILES['pathimage']['name'];
// $imagePath = "Pets/" . $pathimage;

// $tmp_name =  $_FILES['pathimage']['tmp_name'];
// move_uploaded_file($tmp_name, $imagePath);

$last_insert_id = "";


$sql = "SELECT `AUTO_INCREMENT`
    FROM  INFORMATION_SCHEMA.TABLES
    WHERE TABLE_SCHEMA = 'final_project'
    AND   TABLE_NAME   = 'petss';";

// get data
$result = $db->query($sql);

// display it
if ($result !== false) {
    foreach ($result as $row_next_id ) {
        $last_insert_id = $row_next_id["AUTO_INCREMENT"] -1;
    }
}

$pathimage[] = $_FILES['pathimage']['name'];
$tmpFile[] = $_FILES['pathimage']['tmp_name'];

foreach ($pathimage as $key => $value) {

    $tmpFilevalue = $tmpFile[$key];

    if (move_uploaded_file($tmpFilevalue, 'Pets/' . $value)) {

        // $pets = mysqli_fetch_array($sql);

        $save = $db->query("INSERT INTO image_pets(pathimage,id_pets)VALUES('" . $value . "','$last_insert_id')");
        // $result2 = mysqli_query($db, $save);
        if ($save) {
            echo json_encode(array("mess" => "se"));
        } else {
            echo json_encode(array("mess" => "error" . mysqli_error($db)));
        }
    }
}


mysqli_close($db);
if ($result1 && $result2) {
    echo "game";
} else {
    echo "ss";
}
