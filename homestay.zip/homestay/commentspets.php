<?php
$db = mysqli_connect("localhost", "root", "", "final_project");
if (!$db) {
    echo "Database connect error" . mysqli_error($db);
}

$id = $_POST['pets_id'];
$list = array();
$result = $db->query("SELECT * FROM commentspets WHERE pets_id =  '" . $id . "'");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $list[] = $row;
    }
    echo json_encode($list);
}
