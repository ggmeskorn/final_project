<?php
    $db = mysqli_connect("localhost","root","","final_project");
    if(!$db){
            echo "Database connect error".mysqli_error($db);
    }
    $id = $_POST['id'];
    $name_category = $_POST["name_category"];
    $curDate = date('d/m/Y');

    $db->query("UPDATE category_pets SET name_category = '".$name_category."', update_at = '".$curDate."' WHERE id = '".$id."'");