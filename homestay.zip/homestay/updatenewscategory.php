<?php
    $db = mysqli_connect("localhost","root","","final_project");
    if(!$db){
            echo "Database connect error".mysqli_error($db);
    }
    $id = $_POST['id'];
    $news_category = $_POST["news_category"];
    $curDate = date('d/m/Y');

    $db->query("UPDATE category_news SET news_category = '".$news_category."', update_at = '".$curDate."' WHERE id = '".$id."'");